package ooredoocustomfunctions;

import com.tibco.xml.cxf.common.annotations.XPathFunction;
import com.tibco.xml.cxf.common.annotations.XPathFunctionGroup;
import com.tibco.xml.cxf.common.annotations.XPathFunctionParameter;

@XPathFunctionGroup(category = "Custom Functions", prefix = "ooredoo", namespace = "com.ooredoo.custom.functions", helpText = "Ooredoo Custom Functions")
public class CustomFunctions {

	@XPathFunction(helpText = "Push data into cache", parameters = {
			@XPathFunctionParameter(name = "key", optional = false, optionalValue = ""),
			@XPathFunctionParameter(name = "type", optional = false, optionalValue = ""),
			@XPathFunctionParameter(name = "delimitedValue", optional = false, optionalValue = ""),
			@XPathFunctionParameter(name = "delimitor", optional = true, optionalValue = "|") })
	public boolean pushDataInCache(String key, String type, String delimitedValue,
			String delimitor) {
		return CacheHandler.pushData(key, type, delimitedValue, delimitor);
	}

	@XPathFunction(helpText = "Fetch data from cache", parameters = {
			@XPathFunctionParameter(name = "key", optional = false, optionalValue = ""),
			@XPathFunctionParameter(name = "type", optional = false, optionalValue = ""),
			@XPathFunctionParameter(name = "valueIndex", optional = true, optionalValue = "0") })
	public String fetchDataFromCache(String key, String type, int valueIndex) {
		return CacheHandler.fetchData(key, type, valueIndex);
	}

	@XPathFunction(helpText = "Fetch the first data of the given key and type from cache", parameters = {
			@XPathFunctionParameter(name = "key", optional = false, optionalValue = ""),
			@XPathFunctionParameter(name = "type", optional = false, optionalValue = "") })
	public String fetchFirstDataFromCache(String key, String type) {
		return CacheHandler.fetchFirstData(key, type);
	}

	@XPathFunction(helpText = "Fetch the last data of the given key and type from the cache", parameters = {
			@XPathFunctionParameter(name = "key", optional = false, optionalValue = ""),
			@XPathFunctionParameter(name = "type", optional = false, optionalValue = "") })
	public String fetchLastDataFromCache(String key, String type) {
		return CacheHandler.fetchLastData(key, type);
	}

	@XPathFunction(helpText = "Refresh Cache of given type or key or both", parameters = {
			@XPathFunctionParameter(name = "type", optional = false, optionalValue = ""),
			@XPathFunctionParameter(name = "key", optional = true, optionalValue = "") })
	public boolean refreshCache(String type, String key) {
		return CacheHandler.refreshData(type, key);
	}

	@XPathFunction(helpText = "Refresh the entire cache", parameters = {})
	public boolean refreshEntireCache() {
		return CacheHandler.refresh();
	}
}
