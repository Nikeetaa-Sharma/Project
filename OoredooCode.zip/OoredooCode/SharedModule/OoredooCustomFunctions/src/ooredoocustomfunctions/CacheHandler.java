package ooredoocustomfunctions;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.StringTokenizer;

public class CacheHandler {
	
	private static Map<String, CacheEntity> cacheMap;

	/**
	 * 
	 */
	static {
		cacheMap = new HashMap<String, CacheEntity>();
	}

	/**
	 * @return the cacheMap
	 */
	public static Map<String, CacheEntity> getCacheMap() {
		return cacheMap;
	}

	/**
	 * @param cacheMap the cacheMap to set
	 */
	public static void setCacheMap(Map<String, CacheEntity> cacheMap) {
		CacheHandler.cacheMap = cacheMap;
	}

	public synchronized static boolean pushData(String key, String type, String commaSeperatedValues, String delim){
		if(key != null && type != null && commaSeperatedValues != null) {
			StringTokenizer st = null;
			if(delim == null) {
				delim = "|";
			}
			st = new StringTokenizer(commaSeperatedValues, delim);
			CacheEntity cacheEntity =  new CacheEntity();
			cacheEntity.setKey(key);
			cacheEntity.setType(type);
			List<String> values = new ArrayList<String>();
			while(st.hasMoreElements()){
				String val = (String)st.nextElement();
				values.add(val);
			}
			cacheEntity.setValues(values);
			String mapKey =  key + "_" + type;
			CacheHandler.cacheMap.put(mapKey, cacheEntity);
			return true;
		} 
		
		return false;
	}
	
	public synchronized static String fetchData(String key, String type, int valueIndex){
		
		String outputStr = null;
		
		if(key != null && type != null) {
			String mapKey = key + "_" + type;
			CacheEntity cacheEntity = CacheHandler.cacheMap.get(mapKey);
			if(cacheEntity != null && !cacheEntity.getValues().isEmpty()){
				List<String> values = cacheEntity.getValues();
				int lastIndex = values.size() - 1;
				if(valueIndex <= lastIndex) {
					if(valueIndex == -1) {
						valueIndex = lastIndex;
					}
					outputStr = values.get(valueIndex);
				}
			}
		} 
		
		return outputStr;
	}
	
	public synchronized static String fetchFirstData(String key, String type){
		return fetchData(key, type, 0);
	}
	
	public synchronized static String fetchLastData(String key, String type){
		return fetchData(key, type, -1);
	}
	
	public synchronized static boolean refreshData(String type, String key){
		if(type != "" || type != null){
			String patternKey = "(.*)" + key + "_" + type;
			Set<String> keySet = CacheHandler.cacheMap.keySet();
			Iterator<String> iterator= keySet.iterator();
			while(iterator.hasNext()){
				String mapKey = iterator.next();
				if(mapKey.matches(patternKey)){
					CacheHandler.cacheMap.remove(mapKey);
				}
			}
			return true;
		}
		return false;
	}
	
	public synchronized static boolean refresh(){
		if(CacheHandler.cacheMap !=  null){
			CacheHandler.cacheMap = new HashMap<String, CacheEntity>();
			return true;
		}
		return false;
	}
}
