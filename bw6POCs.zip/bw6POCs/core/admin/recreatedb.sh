#!/bin/bash
#
# Copyright 2013 - 2014 by TIBCO Software Inc. 
# All rights reserved.
#
# This software is confidential and proprietary information of
# TIBCO Software Inc.
#
#

# Global variable initialization
#
thisScript="${0}"
args=( ${@} )

scriptDir=${thisScript%/*}    # Chop off the filename to get the directory base name
scriptName=${thisScript##*/}  # Chop off the directory base name to get just the script name

t_usage()
{
    echo ""
    echo "Usage: ${scriptName} "
    echo "  This script cleans up and recreates the Postgres DB needed by BW6 BookStore REST Sample"
    echo "  found under ${BW_HOME}/samples/binding/rest/BookStore"
    echo
    echo "  [-h|-help] : Prints this help message"
    echo
    exit -1
} # t_usage

t_init()
{
    if [ -z "${TIBCO_HOME}" ]; then
	echo "User Error: TIBCO_HOME env variable not set."
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi

    if [ -z "${BW_HOME}" ]; then
	echo "User Error: BW_HOME env variable not set."
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi

    adminScripts=`which bwadmin.sh`
    res=$?
    if [ ${res} -ne 0 ]; then
	echo "User Error: Could not find bwadmin.sh on PATH"
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi
    export BW_SCRIPTS=${adminScripts%/*}  # Chop off /bwadmin.sh to get the path to the script root

    . ${BW_SCRIPTS}/shCommon.sh
    
    t_commonInit

} # t_init

t_parseArgs()
{
    i=0
    numArgs=${#args[@]}
    valid=0

    while [ ${i} -lt ${numArgs} ]; do
	arg="${args[$i]}"
	case "${arg}" in
	    -h|-help)
		t_usage
		;;
	    *)
		echo "User Error: Unsupported argument ${args}"
		t_usage
		;;
	esac
	i=$(($i + 1))
    done

} # t_parseArgs


#
# Main Starts
#
t_init
t_parseArgs

t_divider
t_sourceBWAgentDBEMSConfig
t_checkPSQLBinary

dbcleanupScript="../../binding/rest/BookStore/scripts/dbcleanup.sql"
t_checkCmdFile "${dbcleanupScript}"

dbsetupScript="../../binding/rest/BookStore/scripts/dbsetup.sql"
t_checkCmdFile "${dbsetupScript}"

t_divider
echo "Dropping existing BookStore table ..."
${psqlExe} -f ${dbcleanupScript} -h ${BWAgentDBHost} -p ${BWAgentDBPort}


echo ""
t_divider
echo "Recreating BookStore table ..."
${psqlExe} -f ${dbsetupScript} -h ${BWAgentDBHost} -p ${BWAgentDBPort}

exit 0

# eof
