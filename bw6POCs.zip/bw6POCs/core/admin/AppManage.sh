#!/bin/bash
#
# Copyright 2013 - 2014 by TIBCO Software Inc. 
# All rights reserved.
#
# This software is confidential and proprietary information of
# TIBCO Software Inc.
#
#

#
# Global variable initialization
#
thisScript="${0}"
scriptDir=${thisScript%/*}    # Chop off the filename to get the directory base name
scriptName=${thisScript##*/}  # Chop off the directory base name to get just the script name
args=( ${@} )

TRUE=1
FALSE=0

Debug=0
BWCmd=""
DomainName=""
EARFile=""
Redeploy=${FALSE}
Mode=""

AppSpaceName=""
AppSpaceDescr=""
AppNodeName=""
AppNodeDescr=""
AppName=""
AppDescr=""
UserName=""
Password=""
Description=""
Profile=""
ProfileFile=""
NoStart=${FALSE}
NoStop=${FALSE}
Timeout=${FALSE}
Force=${FALSE}
Serialize=${FALSE}
ServiceName=""
BindingName=""

#
t_init()
{
    if [ -z "${TIBCO_HOME}" ]; then
	echo "User Error: TIBCO_HOME env variable not set."
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi

    if [ -z "${BW_HOME}" ]; then
	echo "User Error: BW_HOME env variable not set."
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi

    adminScripts=`which bwadmin.sh`
    res=$?
    if [ ${res} -ne 0 ]; then
	echo "User Error: Could not find bwadmin.sh on PATH"
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi
    export BW_SCRIPTS=${adminScripts%/*}  # Chop off /bwadmin.sh to get the path to the script root

    . ${BW_SCRIPTS}/shCommon.sh

    # Sourcing shAppManage.sh - which contains all AppManage helper bash functions
    . ${BW_SCRIPTS}/shAppManage.sh

    t_commonInit

    if [ "${BW_EDITION}" == "bw" ]; then
	ProductName="BW6"
    else
	ProductName="BWX"
    fi

    t_set_newline_IFS
} # t_init

#
t_cleanup()
{
    t_commonCleanup
    t_restore_IFS
} # t_cleanup


t_parsedArgs()
{
    # Hardcoding the debug flag for now
    if [ ${Debug} -eq 1 ]; then
	echo "Parsed Arguments: "
	echo "   Mode           = [${Mode}]"
	echo "   BWCmd          = [${BWCmd}]"
	echo "   DomainName     = [${DomainName}]"
	echo "   AppSpaceName   = [${AppSpaceName}]"
	echo "   EARFile        = [${EARFile}]"
	echo "   AppName        = [${AppName}]"
	echo "   UserName       = [${UserName}]"
	echo "   Password       = [${Password}]"
	echo "   Profile        = [${Profile}]"
	echo "   CredentialFile = [${CredentialFile}]"
	echo "   Description    = [${Description}]"
	echo "   NoStart        = [${NoStart}]"
	echo "   NoStop         = [${NoStop}]"
	echo "   Timeout        = [${Timeout}]"
	echo "   Force          = [${Force}]"
	echo "   Serialize      = [${Serialize}]"
	echo "   ServiceName    = [${ServiceName}]"
	echo "   BindingNam     = [${BindingName}]"

    fi
} # t_parsedArgs

t_computedVariables()
{
    if [ ${Debug} -eq 1 ]; then
	t_divider
	echo "Computed Variables: "
	echo "    AppSpaceName    = [${AppSpaceName}]"
	echo "    AppSpaceDescr   = [${AppSpaceDescr}]"
	# echo "    appSpacePrefix  = [${appSpacePrefix}]"
	echo "    AppNodeName     = [${AppNodeName}]"
	echo "    AppName         = [${AppName}]"
	echo "    Mode            = [${Mode}]"
    fi
} # t_computedVariables

t_featureNotYetImplemented()
{
    t_cmd="${1}"
    echo "${scriptName} : Command [${t_cmd}] not yet implemented in this AppManage emulation utility"
    exit -1
} # t_featureNotYetImplemented

#
#
t_checkForValidValue()
{
    t_cmd="${1}"
    t_arg="${2}"
    t_value="${3}"

    if [ -z "${t_value}" ]; then
	echo "User Input Error: Command line argument [${t_arg}] has an empty input value [${t_value}]"
	t_printHelp "${t_cmd}"	
    fi

    if [[ "${t_value}" == -* ]]; then
	echo "User Input Error: Command line argument [${t_arg}] has an invalid input value [${t_value}]"
	t_printHelp "${t_cmd}"
    fi
} # t_checkForValidValue

t_checkForRequiredConfig()
{
    t_cmd="${1}"
    t_arg="${2}"
    t_value="${3}"

    if [ -z "${t_value}" ]; then
	echo "User Input Error: Required command line argument [${t_arg}] not specified"
	t_printHelp "${t_cmd}"
    fi
} # t_checkForRequiredConfig

t_checkForValidFile()
{
    t_cmd="${1}"
    t_arg="${2}"
    t_value="${3}"
    if [ ! -f "${t_value}" ]; then
	echo "User Input Error: Required Command line argument [${t_arg}] for file [${t_value}] does not exist, or is not a file."
	t_printHelp "${t_cmd}"
    fi
} # t_checkForValidFile

t_validateRequiredArguments()
{
    if [ -z "${BWCmd}" ]; then
	t_printHelp
    fi

    t_checkForRequiredConfig "${BWCmd}" "-domain" "${DomainName}"
    t_checkForRequiredConfig "${BWCmd}" "-ear"    "${EARFile}"
    t_checkForValidFile      "${BWCmd}" "-ear"    "${EARFile}"
} # t_validateRequiredArguments

t_parseArgs()
{
    i=0
    numArgs=${#args[@]}
    valid=0

    while [ ${i} -lt ${numArgs} ]; do
	arg="${args[$i]}"
	case "${arg}" in
	    #
	    # Primary command options processing
	    #
	    -help|-h)
		i=$(($i + 1))
		helpCmd="${args[i]}"
		t_printHelp "${helpCmd}"
		i=$(($i + 1))
		;;
	    -export)
		i=$(($i + 1))
		BWCmd="export"
		t_featureNotYetImplemented "${BWCmd}"
		;;
	    -upload)
		i=$(($i + 1))
		BWCmd="upload"
		;;
	    -config)
		i=$(($i + 1))
		BWCmd="config"
		t_featureNotYetImplemented "${BWCmd}"
		;;
	    -deploy)
		i=$(($i + 1))
		BWCmd="deploy"
		;;
	    -undeploy)
		i=$(($i + 1))
		BWCmd="undeploy"
		;;
	    -delete)
		i=$(($i + 1))
		BWCmd="delete"
		t_featureNotYetImplemented "${BWCmd}"
		;;
	    -start)
		i=$(($i + 1))
		BWCmd="start"
		;;
	    -stop)
		i=$(($i + 1))
		BWCmd="stop"
		;;
	    -kill)
		i=$(($i + 1))
		BWCmd="kill"
		t_featureNotYetImplemented "${BWCmd}"
		;;
	    -moveAppData)
		i=$(($i + 1))
		BWCmd="moveAppData"
		t_featureNotYetImplemented "${BWCmd}"
		;;
	    -truncate)
		i=$(($i + 1))
		BWCmd="truncate"
		t_featureNotYetImplemented "${BWCmd}"
		;;

	    #
	    # Secondary command arguments processing
	    #
	    -domain|-d)
		i=$(($i + 1))
		DomainName="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${DomainName}"
		i=$(($i + 1))
		;;
	    -ear)
		i=$(($i + 1))
		EARFile="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${EARFile}"
		t_checkForValidFile "${BWCmd}" "${arg}" "${EARFile}"
		i=$(($i + 1))
		;;
	    -app)
		i=$(($i + 1))
		AppName="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${AppName}"
		i=$(($i + 1))
		;;
	    -deployconfig)
		i=$(($i + 1))
		ProfileFile="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${ProfileFile}"
		t_checkForValidFile "${BWCmd}" "${arg}" "${ProfileFile}"
		i=$(($i + 1))
		;;
	    -user)
		i=$(($i + 1))
		UserName="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${UserName}"
		i=$(($i + 1))
		;;
	    -password|pw)
		i=$(($i + 1))
		Password="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${Password}"
		i=$(($i + 1))
		;;
	    -cred)
		i=$(($i + 1))
		CredentialFile="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${CredentialFile}"
		t_checkForValidFile "${BWCmd}" "${arg}" "${CredentialFile}"
		i=$(($i + 1))
		;;
	    -desc)
		i=$(($i + 1))
		Description="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${Description}"
		i=$(($i + 1))
		;;
	    -nostart)
		i=$(($i + 1))
		NoStart=${TRUE}
		;;
	    -nostop)
		i=$(($i + 1))
		NoStop=${TRUE}
		;;
	    -timeout)
		i=$(($i + 1))
		Timeout="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${Timeout}"
		i=$(($i + 1))
		;;
	    -force)
		i=$(($i + 1))
		Force=${TRUE}
		;;
	    -serialize)
		i=$(($i + 1))
		Serialize=${TRUE}
		;;
	    -service)
		i=$(($i + 1))
		ServiceName="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${ServiceName}"
		i=$(($i + 1))
		;;
	    -binding)
		i=$(($i + 1))
		BindingName="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${BindingName}"
		i=$(($i + 1))
		;;


	    #
	    # BW6 Augmented Command Options
	    #
	    -show)
		i=$(($i + 1))
		BWCmd="show"
		t_featureNotYetImplemented "${BWCmd}"
		;;
	    -appSpace|-a)
		i=$(($i + 1))
		AppSpaceName="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${AppSpaceName}"
		i=$(($i + 1))
		;;
	    -profile|-p)
		i=$(($i + 1))
		ProfileName="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${ProfileName}"
		i=$(($i + 1))
		;;
	    -profileFile|-pf)
		i=$(($i + 1))
		ProfileFile="${args[i]}"
		t_checkForValidValue "${BWCmd}" "${arg}" "${ProfileFile}"
		t_checkForValidFile "${BWCmd}" "${arg}" "${ProfileFile}"
		i=$(($i + 1))
		;;
	    -debug)
		i=$(($i + 1))
		Debug=1
		;;
	    -sapp)
		i=$(($i + 1))
		Mode="${SAPP_APPSPACE}"
		if [ "${BW_EDITION}" == "bw"]; then
		    echo "Info: Target product is BW, but user explicitly set -sapp mode"
		fi
		;;
	    -mapp)
		i=$(($i + 1))
		Mode="${MAPP_APPSPACE}"
		if [ "${BW_EDITION}" == "bwx"]; then
		    echo "User Input Error: BWX does not support -mapp mode"
		    t_usage
		fi
		;;
	    *)
		echo "User Input Error: Invalid argument [${arg}]"
		break
		;;
	esac
    done

    if [ -z "${Mode}" ]; then
	if [ "${BW_EDITION}" == "bw" ]; then
	    Mode="${MAPP_APPSPACE}"
	else
	    Mode="${SAPP_APPSPACE}"
	fi
    fi
} # t_parseArgs

t_localGenerateDeployCmd()
{
    cmdFile="${1}"
    t_deployGenerateCmdDomain "${cmdFile}"
    t_deployGenerateCmdUpload "${cmdFile}"
    t_deployGenerateCmdAppSpaceAndAppNode "${cmdFile}"
    
    if [ ${appExists} -eq ${TRUE} ]; then
	if [ ${Force} -eq ${TRUE} ]; then 
	    # Since Application already exists, let's undeploy before deploying it again
	    t_deployGenerateCmdUndeploy "${cmdFile}"
	    t_deployGenerateCmdDeploy "${cmdFile}"

	else
	    echo 
	    echo "Application [${AppName}] was already deployed."
	    echo "Application is **not** redeployed."
	    echo "To redeploy, please use the \"-force\" flag to force redeploy."
	fi
    else
	t_deployGenerateCmdDeploy "${cmdFile}"
    fi

    t_deployGenerateCmdStartAppSpace "${cmdFile}"

    if [ ${NoStart} -eq ${TRUE} ]; then
	t_deployGenerateCmdStartAppCommentedOut "${cmdFile}"
    else
	t_deployGenerateCmdStartAppCommentedOut "${cmdFile}"
    fi

    t_incrementIndexesDeploy
} # t_localGenerateDeployCmd

t_executeCommand()
{
    t_divider
    t_sourceIndexesDeploy
    t_sourceMachineList
    t_findRunningBWAgents

    t_computeDeploymentVariables "${EARFile}"
    t_checkExistence

    t_computedVariables

    cmdFile="${scriptDir}/cmd/AppManage_${BWCmd}.cmd"
    echo -n "Generate bwadmin commands file ${cmdFile} "

    t_deployGenerateCmdFileHeader "${cmdFile}"

    case "${BWCmd}" in 
	upload)
	    t_deployGenerateCmdDomain "${cmdFile}"
	    t_deployGenerateCmdUpload "${cmdFile}"
	    ;;
	deploy)
	    t_localGenerateDeployCmd "${cmdFile}"
	    ;;
	undeploy)
	    t_deployGenerateCmdUndeploy "${cmdFile}"
	    ;;
	start)
	    t_deployGenerateCmdStartApp "${cmdFile}"
	    ;;
	stop)
	    t_deployGenerateCmdStopApp "${cmdFile}"
	    ;;
	*)
	    t_featureNotYetImplemented "${BWCmd}"
	    ;;
    esac

    t_deployGenerateCmdFileFooter "${cmdFile}"
    echo " Done."

    ${BW_SCRIPTS}/bwadmin.sh -f ${cmdFile}

} # t_executeCommand


#
# Script Main
#
t_init
t_parseArgs
t_parsedArgs
t_validateRequiredArguments

t_executeCommand

t_cleanup

exit 0

# eof

