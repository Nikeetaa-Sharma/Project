#!/bin/bash
#
# Copyright 2013 - 2014 by TIBCO Software Inc. 
# All rights reserved.
#
# This software is confidential and proprietary information of
# TIBCO Software Inc.
#
#

#
# Global variable initialization
#
thisScript="${0}"
args=( ${@} )

DomainName="BookStore-Domain"
Mode=""
scriptDir=${thisScript%/*}    # Chop off the filename to get the directory base name
scriptName=${thisScript##*/}  # Chop off the directory base name to get just the script name

bwagentIndex=0
httpPort=8601

cmdFile=""

t_usage()
{
    echo 
    echo "Usage: ${scriptName} [-h|-help] [<mode>]"
    echo "  Creates ${DomainName} and deploys all EAR files found under \${BW_HOME}/samples/core/admin/ears/bookstore"
    echo
    echo "    [-h|-help] : Displays this usage message"
    echo "    <mode>     : [-sapp | -mapp]"
    echo
    echo "    -sapp      : Single App AppSpace Deployment Mode - where each appspace supports only one application deployment"
    echo "    -mapp      : Multi  App AppSpace Deployment Mode - where each appspace supports one or more application deployment"
    echo
    echo "  Important Notes: "
    echo "    1. BW6 (BusinessWorks Enterprise) supports both -sapp and -mapp modes.  Default is -mapp"
    echo "    2. BWX (BusinessWorks Express)    supports only -sapp mode"
    echo "    3. This script dynamically creates a bwadmin cmd file in cmd/${DomainName}-<mode>.cmd and executes it"
    echo 
    exit -1
} # t_usage

#
# Initialize and error out early if
t_init()
{
    if [ -z "${TIBCO_HOME}" ]; then
	echo "User Error: TIBCO_HOME env variable not set."
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi

    if [ -z "${BW_HOME}" ]; then
	echo "User Error: BW_HOME env variable not set."
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi

    adminScripts=`which bwadmin.sh`
    res=$?
    if [ ${res} -ne 0 ]; then
	echo "User Error: Could not find bwadmin.sh on PATH"
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi
    export BW_SCRIPTS=${adminScripts%/*}  # Chop off /bwadmin.sh to get the path to the script root

    . ${BW_SCRIPTS}/shCommon.sh

    t_commonInit

    t_set_newline_IFS
} # t_init

#
t_cleanup()
{
    t_commonCleanup
    t_restore_IFS
} # t_cleanup

t_parseArgs()
{
    i=0
    numArgs=${#args[@]}
    valid=0

    while [ ${i} -lt ${numArgs} ]; do
	arg="${args[$i]}"
	case "${arg}" in
	    -h|-help)
		t_usage
		;;
	    -sapp)
		Mode="${SAPP_APPSPACE}"
		if [ "${BW_EDITION}" == "bw" ]; then
		    echo "Info: Target product is BW, but user explicitly set -sapp mode"
		fi
		;;
	    -mapp)
		Mode="${MAPP_APPSPACE}"
		if [ "${BW_EDITION}" == "bwx" ]; then
		    echo "Fatal Error: BWX does not support -mapp mode"
		    t_usage
		fi
		;;
	    *)
		echo "User Error: Invalid argument [${arg}]"
		valid=1
		break
		;;
	esac
	i=$(($i + 1))
    done

    if [ -z "${Mode}" ]; then
	if [ "${BW_EDITION}" == "bw" ]; then
	    Mode="${MAPP_APPSPACE}"
	else
	    Mode="${SAPP_APPSPACE}"
	fi
    fi

    if [ ${valid} -ne 0 ]; then
	t_usage
    fi

} # t_parseArgs

#
# Script Main
#
t_init
t_parseArgs

t_computeCmdFile "${Mode}" "${DomainName}" "${scriptDir}"

if [ "${os}" == "cygwin" ]; then
    profileOption="-p WindowsProfile.substvar"
else
    profileOption="-p UnixProfile.substvar"
fi

t_sourceMachineList
t_generateBWAdminCommands "${cmdFile}" "${DomainName}" "${mode}" "${scriptDir}/ears/bookstore" "com tibco bw sample" "1" "${profileOption}"

echo
echo "bwadmin.sh -f ${cmdFile}"
bwadmin.sh -f ${cmdFile}

t_cleanup

exit 0

# eof

