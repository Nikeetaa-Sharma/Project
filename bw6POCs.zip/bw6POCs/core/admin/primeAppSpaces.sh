#!/bin/bash
#
# Copyright 2013 - 2014 by TIBCO Software Inc. 
# All rights reserved.
#
# This software is confidential and proprietary information of
# TIBCO Software Inc.
#
#

#
# Global variable initialization
#
thisScript="${0}"
args=( ${@} )

NetworkArgs=""

scriptDir=${thisScript%/*}    # Chop off the filename to get the directory base name
scriptName=${thisScript##*/}  # Chop off the directory base name to get just the script name

t_sigHandler()
{
    echo
    echo "${scriptName} received interupt signal.  Cleaning Up."
    echo 
    exit 0
} # t_sigHandler

t_usage()
{
    echo 
    echo "Usage: ${scriptName} [-h|-help] [-network <BWAgent Network Name>]"
    echo "  Finds all Domains and start/stop each AppSpace found"
    echo "  Report time it takes for start and stop of each AppSpace"
    echo
    echo "    [-h|-help]                      : Displays this usage message and exits"
    echo "    -network <BWAgent Network Name> : Connect to a named bwagent Network"
    echo 
    exit -1
} # t_usage

#
# Initialize and error out early if
t_init()
{
    if [ -z "${TIBCO_HOME}" ]; then
	echo "User Error: TIBCO_HOME env variable not set."
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi

    if [ -z "${BW_HOME}" ]; then
	echo "User Error: BW_HOME env variable not set."
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi

    adminScripts=`which bwadmin.sh`
    res=$?
    if [ ${res} -ne 0 ]; then
	echo "User Error: Could not find bwadmin.sh on PATH"
	echo "              source \$BW_HOME/scripts/bashrc.sh"
	echo "            to set env variables TIBCO_HOME, BW_HOME and PATH"
	exit 1
    fi
    export BW_SCRIPTS=${adminScripts%/*}  # Chop off /bwadmin.sh to get the path to the script root

    . ${BW_SCRIPTS}/shCommon.sh

    t_validateEnv
    t_commonInit
    t_set_newline_IFS

} # t_init

#
t_cleanup()
{
    t_commonCleanup
    t_restore_IFS
} # t_cleanup

t_parseArgs()
{
    i=0
    numArgs=${#args[@]}
    valid=0

    while [ ${i} -lt ${numArgs} ]; do
	arg="${args[$i]}"
	case "${arg}" in
	    -h|-help)
		t_usage
		;;
	    -network)
		i=$(($i + 1))
		Network="${args[i]}"
		t_checkArgValidValue "${thisScript}" "${arg}" "${Network}"
		NetworkArgs="-network ${Network}"
		;;
	    *)
		echo "User Error: Invalid argument [${arg}]"
		valid=1
		break
		;;
	esac
	i=$(($i + 1))
    done
} # t_parseArgs


#
# Script Main
#
trap t_sigHandler SIGINT SIGTERM

t_init
t_parseArgs

echo "Searching Domains ..."
DomainsList=`bwadmin.sh ${NetworkArgs} show domains`

t_set_newline_IFS
start=0
for domainName in ${DomainsList} ; do
    if [ ${start} -eq 0 ]; then
	if [ "${domainName}" == "Domains: " ]; then
	    # echo "check for start - [${domainName}] - ready"
	    start=1
	else
	    # echo "check for start - [${domainName}] - skip"
	    start=0
	fi
    else
	# ${domainName} value has white space in its header and tail.  Use Bash's variable 
	# expansion to strip out all white spaces
	DomainName="${domainName//[[:space:]]/}"
	echo "Domain - ${DomainName}"

	AppSpaceList=`bwadmin.sh ${NetworkArgs} show -d ${DomainName} appspaces`

	appSpaceStart=0
	for appSpaceName in ${AppSpaceList} ; do
	    if [ ${appSpaceStart} -eq 0 ]; then
		if [[ ${appSpaceName} =~ ^Name.*Applications$ ]]; then
		    appSpaceStart=1
		else
		    appSpaceStart=0
		fi
	    else
		AppSpaceName=`echo ${appSpaceName} | cut -d ' ' -f 1 `
		echo "  AppSpace - ${AppSpaceName}"
	 
		startAppSpaceLog=${scriptDir}/logs/startAppSpace.log
		startAppSpaceTimeLog=${scriptDir}/logs/startAppSpaceTime.log

		echo "    bwadmin.sh ${NetworkArgs} start -d ${DomainName} appspace ${AppSpaceName}"
		{ time bwadmin.sh ${NetworkArgs} start -d ${DomainName} appspace ${AppSpaceName} >& $startAppSpaceLog ; } >& ${startAppSpaceTimeLog}

		echo -n "    started ${DomainName} ${AppSpaceName} in "
		head -n 2 ${startAppSpaceTimeLog} | tail -1
		echo

		sleep 8

		stopAppSpaceLog=${scriptDir}/logs/stopAppSpace.log
		stopAppSpaceTimeLog=${scriptDir}/logs/stopAppSpaceTime.log

		echo "    bwadmin.sh ${NetworkArgs} stop -d ${DomainName} appspace ${AppSpaceName}"
		{ time bwadmin.sh ${NetworkArgs} stop -d ${DomainName} appspace ${AppSpaceName} >& $stopAppSpaceLog ; } >& ${stopAppSpaceTimeLog}
		echo -n "    stopped ${DomainName} ${AppSpaceName} in "
		head -n 2 ${stopAppSpaceTimeLog} | tail -1
		echo 

	    fi
	done
    fi
done
t_restore_IFS



t_cleanup

exit 0

# eof

