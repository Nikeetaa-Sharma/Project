package tibco.bw.sample.application.execution.event.subscriber;

import org.osgi.service.event.Event;
import org.osgi.service.event.EventHandler;

import com.tibco.bw.runtime.AuditEvent;
import com.tibco.bw.runtime.event.ActivityAuditEvent;
import com.tibco.bw.runtime.event.ProcessAuditEvent;
import com.tibco.bw.runtime.event.TransitionAuditEvent;

// referenced in component.xml
public class BWEventSubscriber implements EventHandler {

	@Override
    public void handleEvent(Event event) {
		AuditEvent auditEvent = (AuditEvent) event.getProperty("eventData");
		if(auditEvent instanceof ProcessAuditEvent) {
			//ProcessInstance data
		    System.out.println(auditEvent.toString());
		} else if(auditEvent instanceof ActivityAuditEvent) {
			//Activity data
		    System.out.println(auditEvent.toString());
		} else if(auditEvent instanceof TransitionAuditEvent) {
			//Transition data
		    System.out.println(auditEvent.toString());
		}
	}
	
}