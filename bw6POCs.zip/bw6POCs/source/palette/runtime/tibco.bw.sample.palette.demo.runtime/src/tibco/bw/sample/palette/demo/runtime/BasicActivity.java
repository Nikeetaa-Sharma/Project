package tibco.bw.sample.palette.demo.runtime;

import org.genxdm.ProcessingContext;
import org.genxdm.io.FragmentBuilder;
import org.genxdm.mutable.MutableModel;
import org.genxdm.mutable.NodeFactory;

import tibco.bw.sample.palette.demo.model.demo.Basic;

import com.tibco.bw.runtime.ActivityFault;
import com.tibco.bw.runtime.ProcessContext;
import com.tibco.bw.runtime.SyncActivity;
import com.tibco.bw.runtime.annotation.Property;
import com.tibco.bw.runtime.util.XMLUtils;

public class BasicActivity<N> extends SyncActivity<N> {

	@Property
	public Basic activityConfig;

	@Override
	public N execute(N inputData, ProcessContext<N> processContext)
			throws ActivityFault {

		ProcessingContext<N> xmlContext = processContext
				.getXMLProcessingContext();
		if (activityLogger.isDebugEnabled()) {
			activityLogger.debug("Input Received:"
					+ XMLUtils.serializeNode(inputData, xmlContext));
		}

		if (inputData != null) {
			MutableModel<N> model = xmlContext.getMutableContext().getModel();
			N dataElement = model.getFirstChildElementByName(inputData, null,
					"data");
			if (dataElement != null) {
				String inputValue = model.getStringValue(dataElement);
				NodeFactory<N> factory = model.getFactory(dataElement);
				N output = buildOutputRootNode(xmlContext);
				// Construct output as per schema
				N dataNode = factory.createElement("", "data", "");
				N dataValueNode = factory.createText(inputValue);
				model.appendChild(dataNode, dataValueNode);
				model.appendChild(output, dataNode);
				return output;
			}
		}

		return null;
	}

	private N buildOutputRootNode(final ProcessingContext<N> xmlContext) {
		final FragmentBuilder<N> builder = xmlContext.newFragmentBuilder();
		builder.startDocument(null, "xml");

		try {
			builder.startElement(activityContext.getActivityOutputType()
					.getTargetNamespace(), activityContext
					.getActivityOutputType().getLocalName(), "demo");
			try {
				// Trivial implementation
			} finally {
				builder.endElement();
			}
		} finally {
			builder.endDocument();
		}
		return xmlContext.getModel().getFirstChild(builder.getNode());
	}

}
