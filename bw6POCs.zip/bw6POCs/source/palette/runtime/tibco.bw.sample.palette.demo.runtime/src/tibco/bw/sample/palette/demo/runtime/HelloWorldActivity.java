/*
 * Copyright� 2012 - 2013 TIBCO Software Inc. 
 * All rights reserved. 
 * 
 * This software is confidential and proprietary information of TIBCO Software Inc.
 */
package tibco.bw.sample.palette.demo.runtime;

import tibco.bw.sample.palette.demo.model.demo.HelloWorld;

import com.tibco.bw.runtime.ActivityFault;
import com.tibco.bw.runtime.ProcessContext;
import com.tibco.bw.runtime.SyncActivity;
import com.tibco.bw.runtime.annotation.Property;

public class HelloWorldActivity<N> extends SyncActivity<N> {

	@Property
	public HelloWorld activityConfig;
	
	@SuppressWarnings("rawtypes")
	@Override
	public N execute(N input, ProcessContext context) throws ActivityFault {
       
		System.out.println(activityConfig.getStatement());
		
		return null;
	}
	 

}
