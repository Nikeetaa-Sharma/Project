package tibco.bw.sample.palette.demo.design.helloworld;

import org.eclipse.swt.widgets.Composite;
import org.eclipse.swt.widgets.Text;

import tibco.bw.sample.palette.demo.design.Messages;
import tibco.bw.sample.palette.demo.model.demo.DemoPackage;
import tibco.bw.sample.palette.demo.model.demo.HelloWorld;

import com.tibco.bw.design.field.BWFieldFactory;
import com.tibco.bw.design.propertysection.AbstractBWTransactionalSection;

/**
 * This property section appears in the General tab whenever a HelloWorld activity
 * is selected in the diagram.
 * 
 * @author hillman
 *
 */
public class HelloWorldGeneralSection extends AbstractBWTransactionalSection {

	/**
	 * User control to modify the statement model attribute.
	 */
	protected Text statementText;
	
	public HelloWorldGeneralSection() {
	}
	

	@Override
	protected Composite doCreateControl(Composite root) {
		// Create a simple 2 column composite to contain the label & text box
		Composite parent = BWFieldFactory.getInstance().createComposite(root, 2);
		
		BWFieldFactory.getInstance().createLabel(parent, Messages.HelloWorldGeneralSection_label, true);
		statementText = BWFieldFactory.getInstance().createTextBox(parent);
		
		return parent;
	}

	@Override
	protected void initBindings() {
		// bind the Text field to the statement model attribute
		getBindingManager().bind(statementText, getInput(), DemoPackage.Literals.HELLO_WORLD__STATEMENT);
	}

	@Override
	protected Class<?> getModelClass() {
		// The core infrastructure uses this class to determine when to show this property section
		// When an activity that contains this model is selected, this property section will be visible.
		return HelloWorld.class;
	}
}
