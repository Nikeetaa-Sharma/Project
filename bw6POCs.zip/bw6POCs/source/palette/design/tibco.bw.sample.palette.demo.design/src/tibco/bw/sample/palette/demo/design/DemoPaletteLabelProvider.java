/*
 * Copyright� 2012 - 2014 TIBCO Software Inc. 
 * All rights reserved. 
 * 
 * This software is confidential and proprietary information of TIBCO Software Inc.
 */
package tibco.bw.sample.palette.demo.design;

import java.util.ResourceBundle;


import com.tibco.bw.design.api.BWAbstractActivityLabelProvider;

/**
 * Demonstration label provider that provides all of the labels and images for the palette.
 * 
 * @author hillman
 *
 */
public class DemoPaletteLabelProvider extends BWAbstractActivityLabelProvider {

	/**
	 * Use a single static instance for consistent use of the same provider.
	 */
	public static DemoPaletteLabelProvider INSTANCE = new DemoPaletteLabelProvider();

	/**
	 * Implementing this method allows the base class to determine the location for localized
	 * strings.  All localizations are then handled automatically based on model names.
	 */
	protected ResourceBundle getResourceBundle() {
		return Messages.getBundle();
	}

}
