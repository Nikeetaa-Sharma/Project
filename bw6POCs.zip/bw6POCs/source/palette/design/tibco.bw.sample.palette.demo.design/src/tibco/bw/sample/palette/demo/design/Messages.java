/*
 * Copyright� 2011 - 2014 TIBCO Software Inc. 
 * All rights reserved. 
 * 
 * This software is confidential and proprietary information of TIBCO Software Inc.
 */
package tibco.bw.sample.palette.demo.design;

import java.util.ResourceBundle;

import org.eclipse.osgi.util.NLS;

/**
 * Generated file for localized property strings.
 * 
 * @author hillman
 *
 */
public class Messages extends NLS {

	protected static final String BUNDLE_NAME = "tibco.bw.sample.palette.demo.design.messages"; //$NON-NLS-1$

	static {
		// initialize resource bundle
		NLS.initializeMessages(BUNDLE_NAME, Messages.class);
	}


	protected static ResourceBundle getBundle() {
		return ResourceBundle.getBundle(BUNDLE_NAME);
	}


	public static String HelloWorldGeneralSection_label;

}
