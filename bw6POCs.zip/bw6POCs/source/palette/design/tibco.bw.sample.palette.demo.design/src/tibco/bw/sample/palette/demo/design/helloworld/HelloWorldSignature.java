/*
 * Copyright� 2011 - 2014 TIBCO Software Inc. 
 * All rights reserved. 
 * 
 * This software is confidential and proprietary information of TIBCO Software Inc.
 */
package tibco.bw.sample.palette.demo.design.helloworld;

import java.util.List;

import org.eclipse.xsd.XSDElementDeclaration;

import com.tibco.bw.design.api.BWActivitySignature;
import com.tibco.bw.model.activityconfig.Configuration;

/**
 * The HelloWorld activity does not require any input or output and it
 * does not throw any faults.  The activity is configured solely from
 * its Property sections which configure the activity model.
 * 
 * @author hillman
 *
 */
public class HelloWorldSignature extends BWActivitySignature {

	/**
	 * This activity requires no input.
	 */
	public boolean hasInput() {
		return false;
	}

	/**
	 * this activity has no output
	 */
	public boolean hasOutput() {
		return false;
	}

	@Override
	public XSDElementDeclaration getInputType(Configuration config) {
		return null;
	}

	@Override
	public XSDElementDeclaration getOutputType(Configuration config) {
		return null;
	}

	@Override
	public List<XSDElementDeclaration> getFaultTypes(Configuration config) {
		return null;
	}

}
