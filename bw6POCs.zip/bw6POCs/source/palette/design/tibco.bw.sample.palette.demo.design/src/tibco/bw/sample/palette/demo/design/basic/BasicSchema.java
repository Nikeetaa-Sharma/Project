/*
 * Copyright? 2011 - 2014 TIBCO Software Inc. 
 * All rights reserved. 
 * 
 * This software is confidential and proprietary information of TIBCO Software Inc.
 */
package tibco.bw.sample.palette.demo.design.basic;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

import org.eclipse.xsd.XSDElementDeclaration;
import org.eclipse.xsd.XSDSchema;

import com.tibco.bw.design.api.BWExtensionActivitySchema;

/**
 * <code>BasicSchema</code> is a helper class to load and access the signature schema
 * for the Basic activity.
 * <p>
 * The paths and element strings are custom for this activity and make it easy to identify
 * the specific elements from the <code>BWActivitySignature</code> class.
 * <p>
 * The <code>getSchemaAsInputStream</code> uses the class loader to find the .xsd file
 * in the current plugin.  The <code>BWExtensionActivitySchema</code> base class is then
 * able to load and parse the schema.  Custom elements from the loaded schema are then
 * obtained from helper methods in this utility class.
 * <p>
 * The schema must be loaded each time one of the elements is requested, otherwise there
 * will be an internal reference issue with the returned value.  This is inefficient, but
 * it is necessary.
 * <p>
 * @author hillman
 *
 */
public class BasicSchema extends BWExtensionActivitySchema {

	/**
	 * Shared instance to be used by the activity signature methods.
	 */
	protected static BasicSchema INSTANCE = new BasicSchema();

	public static String SCHEMA_FILE_PATH = "/schema/BasicSignature.xsd"; //$NON-NLS-1$
	public static String INPUT_TYPE_ELEMENT_NAME = "BasicParameters"; //$NON-NLS-1$
	public static String OUTPUT_TYPE_ELEMENT_NAME = "BasicParametersOutput"; //$NON-NLS-1$
	public static final String[] FAULT_TYPE_ELEMENT_NAMES = new String[] { "InvalidInputException" }; //$NON-NLS-1$

	@Override
	protected InputStream getSchemaAsInputStream() {
		return getClass().getResourceAsStream(SCHEMA_FILE_PATH);
	}

	public static XSDElementDeclaration getInputType() {
		XSDElementDeclaration activityInputType = null;

		XSDSchema pluginSchema = INSTANCE.loadSchema();
		if (pluginSchema != null) {
			activityInputType = pluginSchema.resolveElementDeclaration(INPUT_TYPE_ELEMENT_NAME);
		}

		return activityInputType;
	}

	public static XSDElementDeclaration getOutputType() {
		XSDElementDeclaration activityOutputType = null;

		XSDSchema pluginSchema = INSTANCE.loadSchema();
		if (pluginSchema != null) {
			activityOutputType = pluginSchema.resolveElementDeclaration(OUTPUT_TYPE_ELEMENT_NAME);
		}

		return activityOutputType;
	}

	public static List<XSDElementDeclaration> getFaultTypes() {
		List<XSDElementDeclaration> faultTypeElements = new ArrayList<XSDElementDeclaration>();
		XSDSchema signatureSchema = INSTANCE.loadSchema();
		for (String faultElementName : FAULT_TYPE_ELEMENT_NAMES) {
			XSDElementDeclaration faultElement = signatureSchema.resolveElementDeclaration(faultElementName);
			if (faultElement != null) {
				faultTypeElements.add(faultElement);
			}
		}
		return faultTypeElements;
	}

}
