/*
 * Copyright? 2011 - 2014 TIBCO Software Inc. 
 * All rights reserved. 
 * 
 * This software is confidential and proprietary information of TIBCO Software Inc.
 */
package tibco.bw.sample.palette.demo.design.basic;

import java.util.List;

import org.eclipse.xsd.XSDElementDeclaration;

import com.tibco.bw.design.api.BWActivitySignature;
import com.tibco.bw.model.activityconfig.Configuration;

/**
 * The Basic activity signature includes input, output, and faults types.
 * All are defined statically in a schema contained in the plugin.
 * 
 * @author hillman
 *
 */
public class BasicSignature extends BWActivitySignature {

	/**
	 * Activity requires input.
	 */
	public boolean hasInput() {
		return true;
	}

	/**
	 * Activity provides output.
	 */
	public boolean hasOutput() {
		return true;
	}

	@Override
	public XSDElementDeclaration getInputType(Configuration config) {
		return BasicSchema.getInputType();
	}

	@Override
	public XSDElementDeclaration getOutputType(Configuration config) {
		return BasicSchema.getOutputType();
	}

	@Override
	public List<XSDElementDeclaration> getFaultTypes(Configuration config) {
		return BasicSchema.getFaultTypes();
	}

}
