package tibco.bw.sample.palette.demo.design.helloworld;

import org.eclipse.emf.ecore.EObject;
import org.eclipse.jface.viewers.ILabelProvider;

import tibco.bw.sample.palette.demo.design.DemoPaletteLabelProvider;
import tibco.bw.sample.palette.demo.model.demo.DemoFactory;
import tibco.bw.sample.palette.demo.model.demo.HelloWorld;

import com.tibco.bw.design.api.BWAbstractModelHelper;

/**
 * Utility class to help configure the activity models and provide dynamic
 * behavior such as a LabelProvider.
 * 
 * @author hillman
 *
 */
public class HelloWorldModelHelper extends BWAbstractModelHelper {

	public HelloWorldModelHelper() {
	}

	/**
	 * Create an instance of the activity model, filling in default values.
	 */
	@Override
	public EObject createInstance() {
		HelloWorld instance = DemoFactory.eINSTANCE.createHelloWorld();
		instance.setStatement("hello world");
		return instance;
	}

	@Override
	public ILabelProvider getLabelProvider() {
		// provide this mechanism to the core infrastructure to allow it to
		// find appropriate properties defined in message.properties
		return DemoPaletteLabelProvider.INSTANCE;
	}

}
