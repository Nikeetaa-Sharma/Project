/*
 * Copyright� 2014 TIBCO Software Inc.
 * All rights reserved.
 *
 * This software is confidential and proprietary information of TIBCO Software Inc.
 *
 */

package tibco.bw.sample.palette.demo.model.demo;

import com.tibco.bw.validation.exception.ValidationException;
import com.tibco.bw.validation.process.ActivityConfigurationValidator;
import com.tibco.bw.validation.process.ActivityValidationContext;

/**
 * @author <a href="mailto:vnalawad@tibco.com">Vijay Nalawade</a>
 *
 * @since 1.0.0
 */
public class HelloWorldValidator implements ActivityConfigurationValidator {

	/**
	 * @see com.tibco.bw.validation.process.ActivityConfigurationValidator#validateBWActivityConfiguration(com.tibco.bw.validation.process.ActivityValidationContext)
	 */
	public void validateBWActivityConfiguration(
			ActivityValidationContext context) throws ValidationException {
		HelloWorld activityModel = (HelloWorld) context.getActivityConfigurationModel();
		if(activityModel.getStatement() == null || activityModel.getStatement().isEmpty()) {
			context.createError("Statement field can not be empty", "Enter value for the Statement field", "TIB-BW-SAMPLE-500001");
		}
	}

}
