/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package tibco.bw.sample.palette.demo.model.demo;

import org.eclipse.emf.ecore.EAttribute;
import org.eclipse.emf.ecore.EClass;
import org.eclipse.emf.ecore.EPackage;

/**
 * <!-- begin-user-doc -->
 * The <b>Package</b> for the model.
 * It contains accessors for the meta objects to represent
 * <ul>
 *   <li>each class,</li>
 *   <li>each feature of each class,</li>
 *   <li>each enum,</li>
 *   <li>and each data type</li>
 * </ul>
 * <!-- end-user-doc -->
 * @see tibco.bw.sample.palette.demo.model.demo.DemoFactory
 * @model kind="package"
 * @generated
 */
public interface DemoPackage extends EPackage {
	/**
	 * The package name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNAME = "demo";

	/**
	 * The package namespace URI.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_URI = "http://ns.tibco.com/bw/palette/demo";

	/**
	 * The package namespace name.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	String eNS_PREFIX = "demo";

	/**
	 * The singleton instance of the package.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	DemoPackage eINSTANCE = tibco.bw.sample.palette.demo.model.demo.impl.DemoPackageImpl.init();

	/**
	 * The meta object id for the '{@link tibco.bw.sample.palette.demo.model.demo.impl.HelloWorldImpl <em>Hello World</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see tibco.bw.sample.palette.demo.model.demo.impl.HelloWorldImpl
	 * @see tibco.bw.sample.palette.demo.model.demo.impl.DemoPackageImpl#getHelloWorld()
	 * @generated
	 */
	int HELLO_WORLD = 0;

	/**
	 * The feature id for the '<em><b>Statement</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HELLO_WORLD__STATEMENT = 0;

	/**
	 * The number of structural features of the '<em>Hello World</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int HELLO_WORLD_FEATURE_COUNT = 1;


	/**
	 * The meta object id for the '{@link tibco.bw.sample.palette.demo.model.demo.impl.BasicImpl <em>Basic</em>}' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @see tibco.bw.sample.palette.demo.model.demo.impl.BasicImpl
	 * @see tibco.bw.sample.palette.demo.model.demo.impl.DemoPackageImpl#getBasic()
	 * @generated
	 */
	int BASIC = 1;

	/**
	 * The number of structural features of the '<em>Basic</em>' class.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 * @ordered
	 */
	int BASIC_FEATURE_COUNT = 0;


	/**
	 * Returns the meta object for class '{@link tibco.bw.sample.palette.demo.model.demo.HelloWorld <em>Hello World</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Hello World</em>'.
	 * @see tibco.bw.sample.palette.demo.model.demo.HelloWorld
	 * @generated
	 */
	EClass getHelloWorld();

	/**
	 * Returns the meta object for the attribute '{@link tibco.bw.sample.palette.demo.model.demo.HelloWorld#getStatement <em>Statement</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for the attribute '<em>Statement</em>'.
	 * @see tibco.bw.sample.palette.demo.model.demo.HelloWorld#getStatement()
	 * @see #getHelloWorld()
	 * @generated
	 */
	EAttribute getHelloWorld_Statement();

	/**
	 * Returns the meta object for class '{@link tibco.bw.sample.palette.demo.model.demo.Basic <em>Basic</em>}'.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the meta object for class '<em>Basic</em>'.
	 * @see tibco.bw.sample.palette.demo.model.demo.Basic
	 * @generated
	 */
	EClass getBasic();

	/**
	 * Returns the factory that creates the instances of the model.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @return the factory that creates the instances of the model.
	 * @generated
	 */
	DemoFactory getDemoFactory();

	/**
	 * <!-- begin-user-doc -->
	 * Defines literals for the meta objects that represent
	 * <ul>
	 *   <li>each class,</li>
	 *   <li>each feature of each class,</li>
	 *   <li>each enum,</li>
	 *   <li>and each data type</li>
	 * </ul>
	 * <!-- end-user-doc -->
	 * @generated
	 */
	interface Literals {
		/**
		 * The meta object literal for the '{@link tibco.bw.sample.palette.demo.model.demo.impl.HelloWorldImpl <em>Hello World</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see tibco.bw.sample.palette.demo.model.demo.impl.HelloWorldImpl
		 * @see tibco.bw.sample.palette.demo.model.demo.impl.DemoPackageImpl#getHelloWorld()
		 * @generated
		 */
		EClass HELLO_WORLD = eINSTANCE.getHelloWorld();

		/**
		 * The meta object literal for the '<em><b>Statement</b></em>' attribute feature.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @generated
		 */
		EAttribute HELLO_WORLD__STATEMENT = eINSTANCE.getHelloWorld_Statement();

		/**
		 * The meta object literal for the '{@link tibco.bw.sample.palette.demo.model.demo.impl.BasicImpl <em>Basic</em>}' class.
		 * <!-- begin-user-doc -->
		 * <!-- end-user-doc -->
		 * @see tibco.bw.sample.palette.demo.model.demo.impl.BasicImpl
		 * @see tibco.bw.sample.palette.demo.model.demo.impl.DemoPackageImpl#getBasic()
		 * @generated
		 */
		EClass BASIC = eINSTANCE.getBasic();

	}

} //DemoPackage
