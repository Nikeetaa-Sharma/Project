/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package tibco.bw.sample.palette.demo.model.demo;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Basic</b></em>'.
 * <!-- end-user-doc -->
 *
 *
 * @see tibco.bw.sample.palette.demo.model.demo.DemoPackage#getBasic()
 * @model
 * @generated
 */
public interface Basic extends EObject {
} // Basic
