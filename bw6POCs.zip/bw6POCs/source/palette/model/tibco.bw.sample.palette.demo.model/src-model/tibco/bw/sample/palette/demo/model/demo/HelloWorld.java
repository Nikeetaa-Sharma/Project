/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package tibco.bw.sample.palette.demo.model.demo;

import org.eclipse.emf.ecore.EObject;

/**
 * <!-- begin-user-doc -->
 * A representation of the model object '<em><b>Hello World</b></em>'.
 * <!-- end-user-doc -->
 *
 * <p>
 * The following features are supported:
 * <ul>
 *   <li>{@link tibco.bw.sample.palette.demo.model.demo.HelloWorld#getStatement <em>Statement</em>}</li>
 * </ul>
 * </p>
 *
 * @see tibco.bw.sample.palette.demo.model.demo.DemoPackage#getHelloWorld()
 * @model
 * @generated
 */
public interface HelloWorld extends EObject {
	/**
	 * Returns the value of the '<em><b>Statement</b></em>' attribute.
	 * <!-- begin-user-doc -->
	 * <p>
	 * If the meaning of the '<em>Statement</em>' attribute isn't clear,
	 * there really should be more of a description here...
	 * </p>
	 * <!-- end-user-doc -->
	 * @return the value of the '<em>Statement</em>' attribute.
	 * @see #setStatement(String)
	 * @see tibco.bw.sample.palette.demo.model.demo.DemoPackage#getHelloWorld_Statement()
	 * @model
	 * @generated
	 */
	String getStatement();

	/**
	 * Sets the value of the '{@link tibco.bw.sample.palette.demo.model.demo.HelloWorld#getStatement <em>Statement</em>}' attribute.
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @param value the new value of the '<em>Statement</em>' attribute.
	 * @see #getStatement()
	 * @generated
	 */
	void setStatement(String value);

} // HelloWorld
