/**
 * <copyright>
 * </copyright>
 *
 * $Id$
 */
package tibco.bw.sample.palette.demo.model.demo.impl;

import org.eclipse.emf.ecore.EClass;

import org.eclipse.emf.ecore.impl.EObjectImpl;

import tibco.bw.sample.palette.demo.model.demo.Basic;
import tibco.bw.sample.palette.demo.model.demo.DemoPackage;

/**
 * <!-- begin-user-doc -->
 * An implementation of the model object '<em><b>Basic</b></em>'.
 * <!-- end-user-doc -->
 * <p>
 * </p>
 *
 * @generated
 */
public class BasicImpl extends EObjectImpl implements Basic {
	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	protected BasicImpl() {
		super();
	}

	/**
	 * <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	 * @generated
	 */
	@Override
	protected EClass eStaticClass() {
		return DemoPackage.Literals.BASIC;
	}

} //BasicImpl
