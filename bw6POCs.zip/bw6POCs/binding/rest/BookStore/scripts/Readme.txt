Script set up for Postgresql:

Open psql command line utility and at the prompt type
<psqlPrompt>=# \i <pathToScript>/dbsetup.sql

Or from the command line(windows):
psql -f <pathToScript>/dbsetup.sql -U <postgresUser> -h localhost -p 5432


Typically the default user for windows would be 'postgres'. On Unix and mac machines this could be the user login name. Note that all since psql was developed as a unix utility, all paths should be in unix like format i.e. even on windows a path would be using forward slash '/' (e.g. c:/scripts/dbsetup.sql)