

CREATE USER bwuser with password 'bwuser';

CREATE DATABASE bookstore WITH OWNER = bwuser; 

\c bookstore

GRANT ALL ON SCHEMA public to bwuser;
GRANT ALL ON SCHEMA public to public;

-- SET search_path TO public;

CREATE TABLE public.books
(
  isbn text,
  name text,
  description text,
  "authorName" text,
  "releaseDate" date,
  vintage boolean,
  signed boolean,
  price double precision
)
WITH (
  OIDS=FALSE
);

CREATE TABLE public.events
(
  summary text,
  description text,
  "authorName" text,
  bookisbn text,
  date text,
  id text
)
WITH (
  OIDS=FALSE
);


GRANT ALL ON DATABASE bookstore to bwuser;
GRANT ALL ON ALL TABLES IN SCHEMA public to bwuser;

-- INSERT INTO public.books values('1451648537', 'Steve Jobs', 'Biography of Apple Co-Founder Steve Jobs', 'Walter Isaacson', '10/24/2012', false, false, 21.00);
INSERT INTO public.books values('0071450149', 'The Power to Predict', 'How Real Time Businesses Anticipate Customer Needs, Create Opportunities, and Beat the Competition', 'Vivek Ranadive', '2006/01/26', false, true, 15.90);
INSERT INTO public.books values('0061122416', 'The Alchemist', 'Every few decades a book is published that changes the lives of its readers forever. The Alchemist is such a book', 'Paul Coelho', '2006/04/25', true, true, 11.90);

SELECT * FROM public.books;


