package jmexample;

// Copyright 2003 - TIBCO Software Inc.
// ALL RIGHTS RESERVED

/**
 * This class contains customer's acctount information.
 */
public class Account implements java.io.Serializable {
	public String customerLastName = null;
	public String customerFirstName = null;
	public String customerTelephone = null;
}
