package jmexample;

import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.LinkedList;
import java.util.List;
import java.util.StringTokenizer;

import com.tibco.bw.palette.shared.java.JavaProcessStarter;

/**
 * This class allows users to write custom process starters using the java
 * programming language. It extends JavaProcessStarter abstract class that
 * interfaces with the Business works engine. JavaProcessStarter class defines
 * following four abstract methods: 1) init() - Allows users to initialize their
 * resources. 2) onStart() - Allows users to activate their listeners or
 * Observers or kick off a process by calling onEvent(object inputData). 3)
 * onStop() - Allows user to de-activate their listeners or Observers. 4)
 * onShutdown() - Allows users to release the resources. This method is somewhat
 * similar to finalize()
 * 
 * JavaProcessStarter also defines three non-abstract methods: 1)
 * getGlobalInstance() - It returns an instance of Java Global Instance defined
 * in the advanced tab. 2) onEvent(Object object) - It is the main entry point
 * into the Business Works engine. This method must be called in onStart() or in
 * the listener or observer interface to trigger the process. 3)
 * onError(Throwable throwable) - It allows the user to throw an exception if
 * the listener or observer fails to generate an notification event.
 */
public class PublishAllBalancesJavaEventSource extends JavaProcessStarter {
	GetBalancesThread getBalancesThread = null;

	public PublishAllBalancesJavaEventSource() {
	}

	/**
	 * Initializes the Java Event Source component during Business Works engine
	 * start-up. It is highly recommended to initialize resource connections in
	 * this method. Resource connections can also be defined as Java Global
	 * Instance. To configure Java Global Instance use the advanced tab. It is a
	 * common practice to define resource connection as Java Global Instance.
	 * Users can get a handle to the Java Global Instance by calling
	 * this.getJavaGlobalInstance().
	 */
	public void init() throws Exception {
		getBalancesThread = new GetBalancesThread(this);
	}

	/**
	 * This method is called by Business Works engine to activate the Java Event
	 * Source. This is an ideal place for users to add notifier or resource
	 * observer. The notifier/observer can then call onEvent(Object inputData)
	 * method to kick of a process instance.
	 */
	public void onStart() throws Exception {
		Thread thread = new Thread(getBalancesThread);
		thread.start();
	}

	/**
	 * This method is called by Business Works engine to de-activate the Event
	 * Source. User can add code to de-activate a notifier or resource observer.
	 */
	public void onStop() throws Exception {
		getBalancesThread.setFlowControlEnabled(true);
	}

	/**
	 * This method is called at Business Works engine shutdown. User can add
	 * cleanup code in this method
	 */
	public void onShutdown() {
	}

	/*
	 * public Class getOutputObjectType(){ return Collection.class; }
	 */

	public static class GetBalancesThread implements Runnable {
		JavaProcessStarter javaProcessStarter;
		boolean flowControl = false;

		public GetBalancesThread(JavaProcessStarter javaProcessStarter) {
			this.javaProcessStarter = javaProcessStarter;
		}

		public void run() {
			int count = 0;
			while (count <= 0) {
				List<Object> balances = new LinkedList<Object>();
				try {
					BufferedReader in = new BufferedReader(new FileReader(
							"C:\\temp\\AccountInformation.txt"));
					String accountInfo;
					while ((accountInfo = in.readLine()) != null) {
						process(balances, accountInfo);
					}
					in.close();
					try {
						javaProcessStarter.onEvent(balances);
					} catch (Exception ex) {
						ex.printStackTrace();
					}
				} catch (IOException e) {
					e.printStackTrace();
				}
				count++;
			}
		}

		public void process(List<Object> balances, String accountInfo) {
			StringTokenizer strToken = new StringTokenizer(accountInfo, ":");
			int index = 0;

			String accountId = "";
			String firstName = "";
			String lastName = "";
			String checkingBalance = "";
			String savingBalance = "";
			while (strToken.hasMoreTokens()) {
				String token = strToken.nextToken();
				if (index == 0) {
					accountId = token;
				} else if (index == 1) {
					firstName = token;
				} else if (index == 2) {
					lastName = token;
				} else if (index == 3) {
					checkingBalance = token;
				} else if (index == 4) {
					savingBalance = token;
				}
				index++;
			}

			int checkingBalanceAsInt = Integer.valueOf(checkingBalance)
					.intValue();
			;
			int savingBalanceAsInt = Integer.valueOf(savingBalance).intValue();
			;

			Balance balance = new Balance(firstName, lastName, accountId,
					checkingBalanceAsInt, savingBalanceAsInt);
			balances.add(balance);

		}

		public void setFlowControlEnabled(boolean flowControl) {
			this.flowControl = flowControl;
		}
	}
}
