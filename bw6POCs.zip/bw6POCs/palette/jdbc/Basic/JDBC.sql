/*******************************************
   Create test tables
 *******************************************/
   
\c postgres

/* Publication source table */
CREATE TABLE ORDER_TABLE (
   ORDER_ID INTEGER PRIMARY KEY,
   ORDER_DESCRIPTION VARCHAR(128),
   ORDER_PRICE NUMERIC(10,3)
);

/* Create the destination table */
CREATE TABLE SUB_ORDER (
   ORDER_ID INTEGER PRIMARY KEY,
   ORDER_DESCRIPTION VARCHAR(128),
   ORDER_PRICE NUMERIC(10,3)
);



insert into order_table values(142,'TESTING JDBC CONNECTION',3000);
insert into sub_order values(142,'DESTINATION RECORD',2000);
