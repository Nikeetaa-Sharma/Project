#!/bin/bash
#
# Copyright 2013 - 2014 by TIBCO Software Inc. 
# All rights reserved.
#
# This software is confidential and proprietary information of
# TIBCO Software Inc.
#
#

#
# Global variable initialization
#

bwadmin.sh -f cleanupConnectors.cmd


exit 0

# eof

