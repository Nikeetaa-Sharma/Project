#
# Copyright 2013 - 2015 by TIBCO Software Inc. 
# All rights reserved.
#
# This software is confidential and proprietary information of
# TIBCO Software Inc.
#
#

#
# You **must** put in your own twitter application keys in the following settings
#
Twitter_ConsummerKey=Replace_With_Your_Twitter_ConsummerKey

Twitter_ConsummerSecret=Replace_With_Your_Twitter_ConsumerSecret

Twitter_AccessTokenSecret=Replace_With_Your_Twitter_AccessTokenSecret

Twitter_AccessToken=Replace_With_Your_Twitter_AccessToken


#
# You **must** put in your own twilio application keys in the following settings
#
Twilio_AccountSID=Replace_With_Your_Twilio_AccountSID

Twilio_AccessToken=Replace_With_Your_Twilio_AccessToken

PhoneNumber_From=Replace_With_Your_PhoneNumber_From

PhoneNumber_To=Replace_With_Your_PhoneNumber_To


# eof
