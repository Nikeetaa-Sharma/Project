#
# Copyright 2013 - 2015 by TIBCO Software Inc. 
# All rights reserved.
#
# This software is confidential and proprietary information of
# TIBCO Software Inc.
#
#

TwitterConfigList=(
    'Replace_With_Your_Twitter_ConsummerKey'
    'Replace_With_Your_Twitter_ConsumerSecret'
    'Replace_With_Your_Twitter_AccessTokenSecret'
    'Replace_With_Your_Twitter_AccessToken'
)
TwilioConfigList=(
    'Replace_With_Your_Twilio_AccountSID'
    'Replace_With_Your_Twilio_AccessToken'
    'Replace_With_Your_PhoneNumber_From'
    'Replace_With_Your_PhoneNumber_To'
)

t_sourceSampleConfig()
{
    t_configFile="${1}"

    if [ ! -e "${t_configFile}" ]; then
	echo "Fatal Error: ${t_configFile} not found"
	echo "             Please ensure your installation of BW6 is correct and ${scriptDir} contains the required sample_config.sh file"
	exit -1
    fi
    
    echo "Sourcing ${t_configFile}"
    source ${t_configFile}
    res=$?
    if [ ${res} -ne 0 ]; then
	echo "Fatal Error: Sourcing of ${t_configFile} failed"
	echo "             Please ensure your installation of BW6 is correct and ${scriptDir} contains the required sample_config.sh file"
	exit -1
    fi

} # t_sourceSampleConfig

#
# $1 - an array of config params values
# $2 - config file to check and validate
#
t_validateSampleConfig()
{
    declare -a t_configList=( "${!1}" )
    t_configFile="${2}"

    hasUnconfigParam=0
    for config in ${t_configList[@]} ; do
	strRes=`grep ${config}$ ${t_configFile}`
	res=$?
	if [ $res -eq 0 ]; then
	    echo "Error: ${t_configFile} contains unconfigured parameter [${strRes}]"
	    hasUnconfigParam=1
	fi
    done

    if [ ${hasUnconfigParam} -eq 1 ]; then
	t_usage
    fi
} # t_validateSampleConfig

# $1 = template file
# $2 = profile to generate
t_generateSampleProfile()
{
    t_temp="${1}"
    t_profileFile="${2}"

    echo "Generating [${t_profileFile}] from template [${t_temp}]"
    sed -e "s|Replace_With_Your_Twitter_ConsummerKey|${Twitter_ConsummerKey}|g" \
	-e "s|Replace_With_Your_Twitter_ConsumerSecret|${Twitter_ConsummerSecret}|g" \
	-e "s|Replace_With_Your_Twitter_AccessTokenSecret|${Twitter_AccessTokenSecret}|g" \
	-e "s|Replace_With_Your_Twitter_AccessToken|${Twitter_AccessToken}|g" \
	-e "s|Replace_With_Your_Twilio_AccountSID|${Twilio_AccountSID}|g" \
	-e "s|Replace_With_Your_Twilio_AccessToken|${Twilio_AccessToken}|g" \
	-e "s|Replace_With_Your_PhoneNumber_From|${PhoneNumber_From}|g" \
	-e "s|Replace_With_Your_PhoneNumber_To|${PhoneNumber_To}|g" \
	${t_temp} > ${t_profileFile}
}


# eof
