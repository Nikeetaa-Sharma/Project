#!/bin/bash
#
# Copyright 2013 - 2015 by TIBCO Software Inc. 
# All rights reserved.
#
# This software is confidential and proprietary information of
# TIBCO Software Inc.
#
#

# Global variable initialization
#
thisScript="${0}"
scriptDir=${thisScript%/*}    # Chop off the filename to get the directory base name
scriptName=${thisScript##*/}  # Chop off the directory base name to get just the script name
args=( ${@} )

configFile="${scriptDir}/configTemplate.sh"

t_usage()
{
    echo ""
    echo "Usage: ${scriptName} [-h|-help] [-c|-cfg <customizedConfig.sh>]"
    echo "  Setups the Twilio access as a connector service."
    echo ""
    echo "  [-h|-help] : Prints this help message"
    echo "  [-c|-cfg]  : Configuration file to source.  If not specified, default configTemplate.sh is used."
    echo ""
    echo ""
    echo "  You must customize configTemplate.sh with your own Twitter and Twilio Application access tokens"
    echo "  before running this setup script.  Here's the content of configTemplate.sh: "
    echo
    
    cat ${configFile}

    echo
    echo "  ** You must customize sample_config.sh with your own Twitter and Twilio Application access tokens **"
    echo
    exit -1
} # t_usage

t_init()
{
    mkdir -p ./cmd

    if [ ! -e ${scriptDir}/sampleCommon.sh ]; then
	echo "Fatal Error: ${scriptDir}/sampleCommon.sh does not exist"
	exit -1
    fi
    
    source ${scriptDir}/sampleCommon.sh 
} # t_init

t_parseArgs()
{
    i=0
    numArgs=${#args[@]}
    valid=0

    while [ ${i} -lt ${numArgs} ]; do
	arg="${args[$i]}"
	case "${arg}" in
	    -h|-help)
		t_usage
		;;
	    -c|-cfg)
		i=$(($i + 1))
		cfgFile="${args[i]}"
		if [ ! -e "${cfgFile}" ]; then
		    echo "User Error: -c ${cfgFile} - customized config file does not exist."
		    t_usage
		fi
		configFile="${cfgFile}"
		;;
	    *)
		echo "User Error: Invalid argument [${arg}]"
		t_usage
		break
		;;
	esac
	i=$(($i + 1))
    done
} # t_parseArgs

t_init
t_parseArgs

t_sourceSampleConfig "${configFile}"

t_validateSampleConfig TwitterConfigList[@] "${configFile}"
t_validateSampleConfig TwilioConfigList[@]  "${configFile}"

echo "Computing bwagent name using 'hostname -f':"
bwagentName=`hostname -f`
bwagentName=${bwagentName%%\.*}
echo "  bwagentName=[${bwagentName}]"
echo

setupConnectorsTemplate="setupConnectors.cmd"
setupConnectorsCmdFile="./cmd/setupConnectors.cmd"

echo "Generating [${setupConnectorsCmdFile}] from template file [${setupConnectorsTemplate}]"
sed -e "s|\(AgentName=\).*|\1${bwagentName}|g" \
     ${setupConnectorsTemplate} > ${setupConnectorsCmdFile}

t_generateSampleProfile ${scriptDir}/profile/connector.twitter.profile.substvar_template      ${scriptDir}/profile/connector.twitter.profile.substvar
t_generateSampleProfile ${scriptDir}/profile/test.connector.twitter.profile.substvar_template ${scriptDir}/profile/test.connector.twitter.profile.substvar
t_generateSampleProfile ${scriptDir}/profile/tibco.bw.sample.scenario.TwitterAndTwilio.profile.substvar_template ${scriptDir}/profile/tibco.bw.sample.scenario.TwitterAndTwilio.profile.substvar

echo "bwadmin.sh -f ${setupConnectorsCmdFile}"
bwadmin.sh -f ${setupConnectorsCmdFile}


exit 0

# eof

